#!/bin/bash
pymol 1tcd.pml
