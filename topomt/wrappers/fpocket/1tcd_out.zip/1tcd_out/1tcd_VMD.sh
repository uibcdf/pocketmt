#!/bin/bash
vmd 1tcd_out.pdb -e 1tcd.tcl
